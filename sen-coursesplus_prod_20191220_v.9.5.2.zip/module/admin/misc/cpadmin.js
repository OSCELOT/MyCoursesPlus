var tokens = '';
var thisYys = '';
var crsChange = new Boolean(false);

function displayYys(divCourseId,oldCourse){
	Element.update(divCourseId,document.getElementById('coursecode').value); 
	findSeparator(document.getElementById('coursecode').value);
	if (divCourseId,document.getElementById('coursecode').value != oldCourse)
	{
		crsChange = Boolean(true);
	}
	nextFormField('q1','q2','coursecode','idSeparator');
	return false; 
}

function nextFormField(thisField, nextField, thisElement,nextElement){

	if (nextElement == "submit")
	{
		document.getElementById(thisElement).disabled=true; 
		Effect.toggle(thisField+'buttons','appear'); 
		Effect.toggle(nextElement,'appear'); 
	} else{
		Effect.toggle(thisField+'buttons','appear'); 
		if ((thisElement == "idYearStart") || (thisElement == "idSemesterStart"))
		{
			for (num = 1; num < thisYys.length+1; num++) {	
				document.getElementById(thisElement+"_" + num).disabled=true;
		   }
		} else{
			document.getElementById(thisElement).disabled=true; 
		}
		Effect.toggle(nextField,'appear'); 
	}
	return false; 
}


function prevFormField(thisField, prevField, prevElement){ 
	Effect.toggle(thisField,'appear'); 
	Effect.toggle(prevField+'buttons','appear'); 
	if ((prevElement == "idYearStart") || (prevElement == "idSemesterStart"))
	{
		for (num = 1; num < thisYys.length+1; num++) {	
			document.getElementById(prevElement+"_" + num).disabled=false;
		}
            
	} else{

			document.getElementById(prevElement).disabled=false; 
	}
	if ((thisField == "q4") || (thisField == "q6"))
	{
		var eName = "";
		if (thisField == "q4")
		{
			eName = "idYearStart";
		} else if (thisField == "q6"){
			eName = "idSemesterStart";
		}

		if (document.getElementById(eName+"TBody")){
				var remObj = document.getElementById(eName+"TBody")
				remObj.parentNode.removeChild(remObj);
		}
	}
	return false; 
}

function findSeparator(courseCode){

	var sep = "";
	if (!(courseCode.indexOf('.') == -1)){
		sep = ".";
	}
	else if (!(courseCode.indexOf('-') ==-1)){
		sep = "-";
	}
	else if (!(courseCode.indexOf('_') ==-1)){
		sep = "_";
	}
	if (sep != "") {
		Element.update('separator','appears to have a \"'+sep+'\" separator.');
	} else{
		Element.update('separator','does not appear to have a separator.');
	}
	document.getElementById("idSeparator").value = sep;
}

function findTokens(courseCode, separator, oldToken, domObject){
	if (crsChange == Boolean(true))
	{
		oldToken = 1;
	}

	tokens = courseCode.split(separator);
	var thisform = document.getElementById("thisform");
	if (courseCode == tokens){
		Element.update("thisform","<p class='alert'>You did not enter a valid separator and configuration of your course id cannot continue.  Please try again or press the \"Exit\" button to continue without configuring your course id.  Note: My Courses Plus will still work but it cannot sort courses by term or year/semester.</p>");
	} else {
	    removeAllOptions(document.getElementById(domObject));
		var selIndex = 0;
		for (num = 1; num < tokens.length+1; num++) {
			addOption(document.getElementById(domObject), num, tokens[num-1]);
			if (num == (oldToken)){
				selIndex = num -1;
			}
		}
		addOption(document.getElementById(domObject), "0", "Not Listed");
		document.getElementById(domObject).selectedIndex = selIndex;
		Element.update("thisform","<p class='information'>My Courses Plus requires some information about your course codes.  The wizard below will ask you how the course code is made up at your institution.  As is the case for most insitutions, the course code is made up of several parts.  The wizard will try to determine what portion of your course code contains this information.  It is important to note that this portion needs to be fixed length ie. the year and term/semester needs to be the same number of characters for all of your courses for this to work. </p>");
		if (domObject == 'idYearToken')
		{
			nextFormField('q2','q3','idSeparator','idYearToken');
		} else {
			nextFormField('q5','q6','idSeparator','idSemesterToken');
		}
	}
}

function displayYysToken(tokenNumber, eName, oldStart){
	if (tokenNumber == 0){
		Element.update("thisform","<p class='alert'>You did not select a valid term and cannot continue.  Please try again or press the \"Exit\" button to continue without configuring your course id.  Note: My Courses Plus will still work but it cannot sort courses by term or year/semester.</p>");
	} else {
		Element.update("thisform","<p class='information'>My Courses Plus requires some information about your course codes.  The wizard below will ask you how the course code is made up at your institution.  As is the case for most insitutions, the course code is made up of several parts.  The wizard will try to determine what portion of your course code contains this information.  It is important to note that this portion needs to be fixed length ie. the year and term/semester needs to be the same number of characters for all of your courses for this to work. </p>");
		if (crsChange == Boolean(true)){
			oldStart = 1;
		}
		thisYys = tokens[tokenNumber-1];

		if (!(document.getElementById(eName+"TBody"))){
			
			var objTable = document.getElementById(eName+"Table");
			objTableBody = document.createElement("TBODY");
			objTableBody.id = eName+"TBody";
			for (i = 0; i < 2; i++){
				row = document.createElement("TR");
				row.id = eName+"r"+i;
				for (j = 0; j < thisYys.length+1; j++){
					cell = document.createElement("TD");
					cell.id = eName+"r"+i+"c"+j;
					cell.setAttribute("ALIGN","CENTER")
					row.appendChild(cell)
				}
				objTableBody.appendChild(row)
			}
			objTable.appendChild(objTableBody)

			for (num = 0; num < thisYys.length; num++) {	

				var objRadItem;
				try{
					objRadItem = document.createElement("<input type='radio' name='"+eName+"' id='"+eName+"'/>");
				}catch(err){
					objRadItem = document.createElement("input");
					objRadItem.type = "radio";
					objRadItem.name = eName;
				}
				objRadItem.id = eName+"_" + (num+1);
				objRadItem.value = num+1;
				if((oldStart-1) == num) {
					objRadItem.defaultChecked = true; 
					objRadItem.checked = true; 
				}
			    var objCellText = document.getElementById(eName+"r1c"+num);
				objCellText.appendChild(objRadItem);

				var objText = document.createTextNode(" "+thisYys.charAt(num));
			    var objCellLabel = document.getElementById(eName+"r0c"+num);
				objCellLabel.appendChild(objText);
			}
		}	
		if (eName == "idYearStart")
		{
			nextFormField('q3','q4','idYearToken','idYearStart');
		} else if (eName == "idSemesterStart"){
			nextFormField('q6','q7','idYearLen','idSemesterStart');
		}
	}
}

function countYys(eName, value){
	if (crsChange == Boolean(true)){
		value = 1;
	}
	removeAllOptions(document.getElementById(eName),value);

	for (num = 1; num < thisYys.length+1; num++) {
		addOption(document.getElementById(eName), num, num);
	}
	document.getElementById(eName).selectedIndex = (value -1);
	if (eName == "idYearLen")
	{
		nextFormField('q4','q5','idYearStart','idYearLen');
	} else if (eName == "idSemesterLen"){
		nextFormField('q7','q8','idSemesterStart','idSemesterLen');
	}
}


function removeAllOptions(selectbox)
{
	var i;
	for(i=selectbox.options.length-1;i>=0;i--)
	{
		//selectbox.options.remove(i);
		selectbox.remove(i);
	}
}


function addOption(selectbox, value, text)
{
	var optn = document.createElement("OPTION");
	optn.text = text;
	optn.value = value;

	selectbox.options.add(optn);
}

function makeAllAvailable()
{

	document.getElementById("coursecode").disabled=false; 
	document.getElementById("idSeparator").disabled=false; 
	document.getElementById("idYearToken").disabled=false; 
	document.getElementById("idSemesterToken").disabled=false; 


//	document.getElementById("idYearStart").disabled=false; 

	for (var i=0; i<document.courseIdForm.idYearStart.length; i++)  {
		if (document.courseIdForm.idYearStart[i].checked)  {
			var thisElement = document.createElement("input");
			thisElement.type = "hidden";
			thisElement.name = "idYearStart";
			thisElement.value = document.courseIdForm.idYearStart[i].value;
			document.courseIdForm.appendChild(thisElement);
		}
	}
	document.getElementById("idYearLen").disabled=false; 

//	document.getElementById("idSemesterStart").disabled=false; 
	for (var i=0; i<document.courseIdForm.idSemesterStart.length; i++)  {
		if (document.courseIdForm.idSemesterStart[i].checked)  {
			var thisElement = document.createElement("input");
			thisElement.type = "hidden";
			thisElement.name = "idSemesterStart";
			thisElement.value = document.courseIdForm.idSemesterStart[i].value;
			document.courseIdForm.appendChild(thisElement);
		}
	}

	document.getElementById("idSemesterLen").disabled=false; 
	document.getElementById("idFirstStr").disabled=false; 
	document.getElementById("idSecondStr").disabled=false; 
	document.getElementById("idThirdStr").disabled=false; 
	document.getElementById("idFourthStr").disabled=false; 
	document.getElementById("idFifthStr").disabled=false; 
}

function checkQuickToolPad ( enabled, init ){
	if (init == 'true')
	{
		if (enabled == "1")
		{
			Effect.Appear('showTools1'); 
			Effect.Appear('showTools2');
		}
	} else {
		Effect.toggle('showTools1','appear'); 
		Effect.toggle('showTools2','appear'); 
	}
}

function enrollOptions ( enabled ){
	if (enabled == 1)
	{
		for (var i=0; i<document.enrollForm.enrolleeType.length; i++)  {
			document.enrollForm.enrolleeType[i].disabled=false; 
		}
	} else {
		for (var i=0; i<document.enrollForm.enrolleeType.length; i++)  {
			document.enrollForm.enrolleeType[i].disabled=true; 
			document.enrollForm.enrolleeType[i].checked=false; 
		}
	}
}

function StudNoticeOptions ( enabled ){
	if (enabled == 1)
	{
		document.noticeForm.studNotice.disabled=false; 
		document.noticeForm.studNotice.value="Note: Only the courses that your instructors have activated for you will be available within the Blackboard system.";
	} else {
		document.noticeForm.studNotice.disabled=true; 
		document.noticeForm.studNotice.value="";
	}
}

function TeachNoticeOptions ( enabled ){
	if (enabled == 1)
	{
		document.noticeForm.teachNotice.disabled=false; 
	} else {
		document.noticeForm.teachNotice.disabled=true; 
		document.noticeForm.teachNotice.value="";
	}
}




function checkAllEnrollments(numRoles){
	var count=0;
	for (var i=0; i<document.enrollForm.enrolleeType.length; i++)  {
		if (document.enrollForm.enrolleeType[i].checked== true) 
			count++
	}
	if (numRoles == count)
	{
		document.enrollForm.allowChangeRoles.value = "1";
	} 

}