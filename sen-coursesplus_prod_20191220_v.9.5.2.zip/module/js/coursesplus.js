// view.jsp function
function preLoadImages( modDir) {
	// Tree
	var image1 = new Image();
	image1.src = modDir+"images/plus.gif";
	var image2 = new Image();
	image2.src = modDir+"images/minus.gif";
	var image3 = new Image();
	image3.src = modDir+"images/helpbutton.gif";
	var image4 = new Image();
	image4.src = modDir+"images/empty.gif";
	var image5 = new Image();
	image5.src = modDir+"images/tpempty.gif";
	var image6 = new Image();
	image6.src = modDir+"images/line.gif";
	var image7 = new Image();
	image7.src = modDir+"images/tpline.gif";
	var image8 = new Image();
	image8.src = modDir+"images/joinbottom.gif";
	var image9 = new Image();
	image9.src = modDir+"images/join.gif";
	var image10 = new Image();
	image10.src = modDir+"images/tpjoin.gif";
	var image11 = new Image();
	image11.src = modDir+"images/folder.png";

	//Toolbar
	var image20 = new Image();
	image20.src = modDir+"images/tools_ti.gif";
	var image21 = new Image();
	image21.src = modDir+"images/disabledcourse.png";
	var image22 = new Image();
	image22.src = modDir+"images/information.png";
	var image23 = new Image();
	image23.src = modDir+"images/controlpanel.png";
	var image24 = new Image();
	image24.src = modDir+"images/gradebook.png";
	var image25 = new Image();
	image25.src = modDir+"images/announcement.png";
	var image26 = new Image();
	image26.src = modDir+"images/discussion.png";
	var image27 = new Image();
	image27.src = modDir+"images/email.png";
	var image28 = new Image();
	image28.src = modDir+"images/calendar.png";
	var image29 = new Image();
	image29.src = modDir+"images/task.png";
	var image30 = new Image();
	image30.src = modDir+"images/message_li.gif";
	var image31 = new Image();
	image31.src = modDir+"images/enrolloption.png";
	var image32 = new Image();
	image32.src = modDir+"images/idcard.png";
	var image33 = new Image();
	image33.src = modDir+"images/newspaper.png";
	var image34 = new Image();
	image34.src = modDir+"images/announce_perm.png";
	var image35 = new Image();
	image35.src = modDir+"images/announce_new.png";
	var image36 = new Image();
	image36.src = modDir+"images/calendar_today.png";
	var image37 = new Image();
	image37.src = modDir+"images/task_today.png";

// balloon
	var image40 = new Image();
	image40.src = modDir+"images/helpbutton.gif";
	var image41 = new Image();
	image41.src = modDir+"images/icon_info.gif";
	var image42 = new Image();
	image42.src = modDir+"images/balloon.png";
	var image43 = new Image();
	image43.src = modDir+"images/button.png";
	return false;
}

function showClassListMsg (){
	msg = "The Class List View Generator may take a while\ndepending on the speed of your connection.\n\nPlease be patient.";
	alert(msg);
	return true;
}


function changeQTP ( courseId, type)
{
	if (type == 'tool')
	{
		if (document.getElementById('ann_'+courseId))
			Element.hide('ann_'+courseId); 
		if (document.getElementById('cal_'+courseId))
			Element.hide('cal_'+courseId); 
		if (document.getElementById('task_'+courseId))
			Element.hide('task_'+courseId); 
		Effect.toggle('tool_'+courseId,'appear');
	} else {
		if (Element.visible(type+"_"+courseId))
		{
			Element.hide(type+"_"+courseId)
		} else {
			if (type == 'ann'){
				Element.show('ann_'+courseId); 
				Element.hide('cal_'+courseId); 
				Element.hide('task_'+courseId); 
			} else if (type == 'cal'){
				Element.hide('ann_'+courseId); 
				Element.show('cal_'+courseId); 
				Element.hide('task_'+courseId); 
			} else if (type == 'task'){
				Element.hide('ann_'+courseId); 
				Element.hide('cal_'+courseId); 
				Element.show('task_'+courseId); 
			}
		}
	}
}

function courseAvailability(courseId, state, moduleDir) {	
	new Ajax.Request(moduleDir+'module/courseavail.jsp', {method:'post', postBody:'action='+state+'&crs_id='+courseId});

	Effect.toggle('icoAvail'+courseId,'appear');
	if (state == 'avail'){
		Element.update('labelAvail'+courseId,'&nbsp;<span style=\'background-color:#F8FFF0; border:1px solid #A0DC11; padding:0px 3px 0px 3px;  font-size:8px;\'>AVAILABLE...</span>'); 
	} else {
		Element.update('labelAvail'+courseId,'&nbsp;<span style=\'background-color:#F8FFF0; border:1px solid #A0DC11; padding:0px 3px 0px 3px;  font-size:8px;\'>NOT AVAILABLE...</span>'); 
	}
	changeQTP(courseId,'tool');
	Effect.toggle('icoNotAvail'+courseId,'appear');

}
